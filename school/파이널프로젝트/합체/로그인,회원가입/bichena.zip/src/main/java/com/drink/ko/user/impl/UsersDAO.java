package com.drink.ko.user.impl;

import java.util.List;
import java.util.Random;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;

import com.drink.ko.user.UsersVO;

@Repository
public class UsersDAO {

	@Autowired
	private SqlSessionTemplate mybatis;

	@Autowired
	private BCryptPasswordEncoder encoder;

	// 내 정보 수정
	public void updateUser(UsersVO vo) {
		mybatis.update("UserDAO.updateUser", vo);
	}

	// 닉네임 중복검사
	public UsersVO checkNick(String nick) {
		return mybatis.selectOne("UserDAO.checkNick", nick);
	}

	// 회원계정 삭제
	public void deleteUser(UsersVO vo) {
		mybatis.update("UserDAO.deleteUser", vo);
	}

	// 내 정보 상세조회
	public UsersVO selectOne(String selId) {
		return mybatis.selectOne("UserDAO.selectOne", selId);
	}

	// 비밀번호 재확인 후 내 정보 진입
	public UsersVO checkPw(String pw, String id) {
		UsersVO vo = mybatis.selectOne("UserDAO.checkId", id);

		boolean is = encoder.matches(pw, vo.getU_pw());

		if (is) {
			return mybatis.selectOne("userDAO.loginSelectOne", vo);
		} else {
			return null;
		}
	}

	public List<UsersVO> selectList(String keyword) { // 얘는 keyword 던짐
		return mybatis.selectList("UserDAO.selectList", keyword);
	}

	public int insertUser(UsersVO vo) {
		if (vo.getU_nick() == null) {
			vo.setU_nick(vo.getU_name());
		}
		vo.setU_birth(vo.getU_birth().replace("-", ""));
		String encodingStr = encoder.encode(vo.getU_pw());
		vo.setU_pw(encodingStr);

		return mybatis.insert("UserDAO.insertUser", vo);
	}

	public UsersVO checkId(String id) {
		return mybatis.selectOne("UserDAO.checkId", id);
	}

	// 로그인
	public UsersVO loginSelectOne(UsersVO vo) {
		System.out.println("UserDAOMybatis를 탔습니다.");

		System.out.println("loginSelectOne  else : " + vo.getU_id());
		UsersVO gap = mybatis.selectOne("UserDAO.checkId", vo.getU_id());
		if (gap == null) {
			return null;
		}
		boolean is = encoder.matches(vo.getU_pw(), gap.getU_pw());
		System.out.println("is : " + is);
		if (is) {
			vo.setU_pw(gap.getU_pw());
			return mybatis.selectOne("userDAO.loginSelectOne", vo);
		} else {
			return null;
		}

	}

	public UsersVO idFindEmail(UsersVO vo) {
		System.out.println("idFind의 UserDAOMybatis를 탔습니다.");
		System.out.println("idFind의 Username : " + vo.getU_email());
		return mybatis.selectOne("userDAO.idFindEmail", vo);
	}

	public UsersVO idFindPhon(UsersVO vo) {
		System.out.println("idFindPhon의 UserDAOMybatis를 탔습니다.");
		System.out.println("idFind의 Username : " + vo.getU_email());
		return mybatis.selectOne("userDAO.idFindPhon", vo);
	}

	public int pwFind(UsersVO vo) {
		return mybatis.selectOne("userDAO.pwFind", vo);
	}

	public UsersVO pwFindStart(UsersVO vo) {
		Random rnd = new Random();

		StringBuffer randomAlpanumerics = new StringBuffer();

		for (int i = 0; i < 12; i++) {
			if (i < 5)
				randomAlpanumerics.append((char) ((rnd.nextInt(26)) + 'A'));
			else
				randomAlpanumerics.append(rnd.nextInt(10));
		}

		System.out.println("randomAlpanumerics : " + randomAlpanumerics);
		String random = randomAlpanumerics.toString();
		vo.setN_pw(random);
		int i = mybatis.update("userDAO.pwFindStart", vo);

		if (i == 0) {
			System.out.println("pwFindStart : 에러에러에러");
		} else if (i > 0) {
			mybatis.selectOne("userDAO.selectPW", vo);
			return mybatis.selectOne("userDAO.selectPW", vo);
		}
//			return mybatis.update("userDAO.pwFindStart",vo);
		return null;
	}

	public int kakaoLoginFirst(UsersVO vo) {
		return mybatis.insert("userDAO.kakaoLoginFirst", vo);
	}

	public UsersVO kakaoLogin(UsersVO vo) {
		return mybatis.selectOne("userDAO.kakaoLogin", vo);
	}
}
